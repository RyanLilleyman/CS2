#This is a humble introduction
into the world of classes and object oriented programming.
In this project you will find different concepts like
polymorphism, inheritance, method overloading, etc...
